`timescale 1ns / 1ps

module vga_controller(
    input CLK,         // 100MHz clock
    input RESET,       // system reset
    output hsync,      // horizontal sync
    output vsync,      // vertical sync 
    output video_on,   // display enable
    output p_tick,     // 25MHz pixel tick
    output [9:0] x,    // pixel x position
    output [9:0] y     // pixel y position
);
    
    // VGA 640x480 timing parameters
    parameter H_DISPLAY = 640;  // horizontal display area
    parameter H_BACK    = 48;   // horizontal back porch
    parameter H_FRONT   = 16;   // horizontal front porch
    parameter H_SYNC    = 96;   // horizontal sync pulse
    parameter H_MAX     = H_DISPLAY + H_BACK + H_FRONT + H_SYNC - 1;
    
    parameter V_DISPLAY = 480;  // vertical display area
    parameter V_BACK    = 33;   // vertical back porch
    parameter V_FRONT   = 10;   // vertical front porch
    parameter V_SYNC    = 2;    // vertical sync pulse
    parameter V_MAX     = V_DISPLAY + V_BACK + V_FRONT + V_SYNC - 1;
    
    // Generate 25MHz pixel clock
    reg [1:0] count = 0;
    wire tick;
    
    always @(posedge CLK or posedge RESET)
        if (RESET)
            count <= 0;
        else
            count <= count + 1;
    
    assign tick = (count == 0);  // 25MHz tick (divides 100MHz by 4)
    
    // Counter registers for pixel positions
    reg [9:0] h_count = 0;
    reg [9:0] v_count = 0;
    
    // Horizontal and vertical sync registers
    reg h_sync_reg = 0;
    reg v_sync_reg = 0;
    
    // Update pixel position at 25MHz
    always @(posedge CLK)
        if (RESET) begin
            h_count <= 0;
            v_count <= 0;
        end
        else if (tick) begin
            // Update horizontal counter
            if (h_count == H_MAX)
                h_count <= 0;
            else
                h_count <= h_count + 1;
                
            // Update vertical counter
            if (h_count == H_MAX) begin
                if (v_count == V_MAX)
                    v_count <= 0;
                else
                    v_count <= v_count + 1;
            end
        end
    
    // Generate sync signals (active LOW)
    always @(posedge CLK)
        if (RESET) begin
            h_sync_reg <= 1;
            v_sync_reg <= 1;
        end
        else if (tick) begin
            // Horizontal sync
            h_sync_reg <= ~(h_count >= (H_DISPLAY + H_FRONT) && 
                            h_count < (H_DISPLAY + H_FRONT + H_SYNC));
            
            // Vertical sync
            v_sync_reg <= ~(v_count >= (V_DISPLAY + V_FRONT) && 
                            v_count < (V_DISPLAY + V_FRONT + V_SYNC));
        end
    
    // Video on/off
    assign video_on = (h_count < H_DISPLAY) && (v_count < V_DISPLAY);
    
    // Output assignments
    assign hsync = h_sync_reg;
    assign vsync = v_sync_reg;
    assign x = h_count;
    assign y = v_count;
    assign p_tick = tick;
    
endmodule