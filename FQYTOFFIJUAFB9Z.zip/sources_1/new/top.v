module top(
    // System Clock & Reset
    input CLK,
    input RST, 
    
    // VGA Ports
    output hsync,
    output vsync,
    output [3:0] vgaRed,
    output [3:0] vgaGreen,
    output [3:0] vgaBlue,

    // PmodJSTK 1 Ports (Switches, LEDs, 7-Seg, SPI)
    input [2:0] SW,
    output [2:0] LED,
    output [6:0] SEG,
    output [3:0] AN,
    output SS,
    output MOSI,
    input MISO,
    output SCLK,
    
    // PmodJSTK 2 Ports (Right Paddle SPI)
    output SS2,
    output MOSI2,
    input MISO2,
    output SCLK2
);

    // ==========================================
    // VGA Logic 
    // ==========================================
    wire video_on;
    wire p_tick;
    wire [9:0] x, y;

    // Instantiate your VGA sync module
    vga_controller sync (
        .CLK(CLK),
        .RESET(RST),
        .hsync(hsync),
        .vsync(vsync),
        .video_on(video_on),
        .p_tick(p_tick),
        .x(x),
        .y(y)
    );
    
    // ==========================================
    // PmodJSTK 1 Instantiation (Left Paddle)
    // ==========================================
    wire [9:0] jstk_y; // Wire to grab the Y-axis data from joystick 1

    PmodJSTK_Demo jstk_demo_inst (
        .CLK(CLK),
        .RST(RST),
        .SW(SW),
        .MISO(MISO),
        .SS(SS),
        .MOSI(MOSI),
        .SCLK(SCLK),
        .LED(LED),
        .AN(AN),
        .SEG(SEG),
        .jstk_y(jstk_y) 
    );
    
    // ==========================================
    // PmodJSTK 2 Instantiation (Right Paddle)
    // ==========================================
    wire sndRec2;
    wire [39:0] jstkData2;
    wire [9:0] jstk_y2;

    // Polling clock divider
    ClkDiv_100Hz genSndRec2 (
        .CLK(CLK),
        .RST(RST),
        .CLKOUT(sndRec2)
    );

    // Instantiate base SPI controller for Joystick 2
    PmodJSTK jstk2_inst (
        .CLK(CLK),
        .RST(RST),
        .sndRec(sndRec2),
        .DIN(8'h80),     // Send default byte (keeps joystick LEDs off)
        .MISO(MISO2),
        .SS(SS2),
        .SCLK(SCLK2),
        .MOSI(MOSI2),
        .DOUT(jstkData2)
    );
    
    // Extract Y axis data from Joystick 2's SPI payload
    assign jstk_y2 = {jstkData2[25:24], jstkData2[39:32]};

    // ==========================================
    // Pong Paddle Layout & Movement
    // ==========================================
    
    // Generate a 60Hz single-cycle tick at the start of Vertical Blanking
    wire frame_tick = (x == 0 && y == 481 && p_tick);

    // Deadzone constants (approx +/- 20 units is ~0.02 of the 1024 range)
    localparam JSTK_CENTER   = 10'd512;
    localparam JSTK_DEADZONE = 10'd40; 

    reg [9:0] left_paddle_y = 10'd200;
    reg [9:0] right_paddle_y = 10'd200;
    
    // Calculate proportional speeds for both paddles
    wire [9:0] speed_up  = ((JSTK_CENTER - jstk_y) >> 5) + 1'b1;
    wire [9:0] speed_dn  = ((jstk_y - JSTK_CENTER) >> 5) + 1'b1;
    
    wire [9:0] speed_up2 = ((JSTK_CENTER - jstk_y2) >> 5) + 1'b1;
    wire [9:0] speed_dn2 = ((jstk_y2 - JSTK_CENTER) >> 5) + 1'b1;

    // ==========================================
    // Ball Variables & Random Angle Generator
    // ==========================================
    reg [9:0] ball_x = 10'd315;
    reg [9:0] ball_y = 10'd235;
    
    reg [9:0] ball_vx; 
    reg [9:0] ball_vy;

    // Fast running counter for pseudo-random number generation (0 to 4)
    reg [2:0] rand_cnt = 0;
    always @(posedge CLK) begin
        if (rand_cnt == 3'd4)
            rand_cnt <= 0;
        else
            rand_cnt <= rand_cnt + 1;
    end

    // ==========================================
    // Main Game Logic Update
    // ==========================================
    always @(posedge CLK) begin
        if (RST) begin
            left_paddle_y <= 10'd200;
            right_paddle_y <= 10'd200;
            
            ball_x <= 10'd315;
            ball_y <= 10'd235;
            ball_vx <= -10'd2; // Always moving left on reset
            
            // Map the random counter to Y velocities: -2, -1, 0, 1, 2
            case(rand_cnt)
                3'd0: ball_vy <= -10'd2;
                3'd1: ball_vy <= -10'd1;
                3'd2: ball_vy <= 10'd0;
                3'd3: ball_vy <= 10'd1;
                3'd4: ball_vy <= 10'd2;
                default: ball_vy <= 10'd0;
            endcase
            
        end else if (frame_tick) begin
            
            // --- Left Paddle Movement ---
            if (jstk_y < (JSTK_CENTER - JSTK_DEADZONE)) begin
                if (left_paddle_y > speed_up)
                    left_paddle_y <= left_paddle_y - speed_up;
                else
                    left_paddle_y <= 10'd0;
            end 
            else if (jstk_y > (JSTK_CENTER + JSTK_DEADZONE)) begin
                if (left_paddle_y + speed_dn < 10'd400)
                    left_paddle_y <= left_paddle_y + speed_dn;
                else
                    left_paddle_y <= 10'd400;
            end
            
            // --- Right Paddle Movement (INVERTED) ---
            if (jstk_y2 < (JSTK_CENTER - JSTK_DEADZONE)) begin
                if (right_paddle_y + speed_up2 < 10'd400)
                    right_paddle_y <= right_paddle_y + speed_up2;
                else
                    right_paddle_y <= 10'd400;
            end 
            else if (jstk_y2 > (JSTK_CENTER + JSTK_DEADZONE)) begin
                if (right_paddle_y > speed_dn2)
                    right_paddle_y <= right_paddle_y - speed_dn2;
                else
                    right_paddle_y <= 10'd0;
            end
            
            // --- Ball Collision & Movement ---
            
            // 1. Top and Bottom Wall Collisions
            // Screen is 480px high, ball is 10px. 
            if (ball_y == 10'd0 || ball_y > 10'd500) begin
                // Hits top edge (or wraps around below 0 to 1023)
                ball_vy <= (ball_vy[9]) ? -ball_vy : ball_vy; // Force move down (positive Y)
                ball_y <= 10'd1;
            end else if (ball_y >= 10'd470 && ball_y < 10'd500) begin
                // Hits bottom edge
                ball_vy <= (~ball_vy[9]) ? -ball_vy : ball_vy; // Force move up (negative Y)
                ball_y <= 10'd469;
            end else begin
                ball_y <= ball_y + ball_vy;
            end
            
            // 2. Paddle Collisions
            // Left Paddle (Right edge is at X=60)
            if (ball_x <= 10'd60 && ball_x > 10'd40 && 
                (ball_y + 10'd10 >= left_paddle_y) && (ball_y <= left_paddle_y + 10'd80)) begin
                
                // If velocity MSB is 1 (negative), invert it. Otherwise, keep it.
                ball_vx <= (ball_vx[9]) ? -ball_vx : ball_vx; 
                ball_x <= 10'd61;    // Snap just outside the paddle
            end 
            // Right Paddle (Left edge is at X=590)
            else if (ball_x + 10'd10 >= 10'd590 && ball_x < 10'd610 && 
                     (ball_y + 10'd10 >= right_paddle_y) && (ball_y <= right_paddle_y + 10'd80)) begin
                     
                // If velocity MSB is 0 (positive), invert it. Otherwise, keep it.
                ball_vx <= (~ball_vx[9]) ? -ball_vx : ball_vx;
                ball_x <= 10'd579;   // Snap just outside the paddle
            end 
            // No paddle hit, move horizontally normally
            else begin
                ball_x <= ball_x + ball_vx;
            end
            
        end
    end
    
    // ==========================================
    // VGA Rendering
    // ==========================================
    
    // Define paddle boundaries
    wire left_paddle =  (x >= 50 && x < 60) && 
                        (y >= left_paddle_y && y < left_paddle_y + 80);
                       
    wire right_paddle = (x >= 590 && x < 600) && 
                        (y >= right_paddle_y && y < right_paddle_y + 80);

    // Define ball boundaries (10x10 pixels)
    wire ball_draw = (x >= ball_x && x < ball_x + 10) && 
                     (y >= ball_y && y < ball_y + 10);

    // Draw the paddles and ball in white
    assign vgaRed   = (video_on && (left_paddle || right_paddle || ball_draw)) ? 4'hF : 4'h0;
    assign vgaGreen = (video_on && (left_paddle || right_paddle || ball_draw)) ? 4'hF : 4'h0;
    assign vgaBlue  = (video_on && (left_paddle || right_paddle || ball_draw)) ? 4'hF : 4'h0;

endmodule