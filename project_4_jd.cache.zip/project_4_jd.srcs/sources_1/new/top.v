
module top(
    input CLK,
    input RESET,
    input Mouse_Clk,
    input Mouse_Data, 
    
    
    output hsync,
    output vsync,
    output [3:0] vgaRed,
    output [3:0] vgaGreen,
    output [3:0] vgaBlue
);

    wire video_on;
    wire p_tick;
    wire [9:0] x, y;

    // Instantiate your VGA sync module
    vga_controller sync (
        .CLK(CLK),
        .RESET(RESET),
        .hsync(hsync),
        .vsync(vsync),
        .video_on(video_on),
        .p_tick(p_tick),
        .x(x),
        .y(y)
    );

    // Define a rectangle
    wire rectangle;
    assign rectangle = (x >= 180 && x < 380) &&
                       (y >= 140 && y < 280);

    // Set pixel colors
    assign vgaRed   = (video_on && rectangle) ? 4'hF : 4'h0;
    assign vgaGreen = 4'h0;
    assign vgaBlue  = 4'h0;
    
    
    // Mouse stuff
    wire [9:0] mouse_x;
    wire [9:0] mouse_y;
    wire left_click, right_click;
    
  //declare mouse module 
    
    wire cursor_on;
    
    assign cursor_on =
        (x >= mouse_x && x < mouse_x + 8) &&
        (y >= mouse_y && y < mouse_y + 8);

endmodule


