`timescale 1ns / 1ps

module ps2_mouse(
    input CLK,                     // 100MHz clock
    input RESET,                   // system reset
    input Mouse_Data,              // PS/2 Data (PS2Data)
    input Mouse_Clk,               // PS/2 Clock (PS2Clk)
    output mouse_x,
    output mouse_y,
    output reg left_click,         // High when left button is pressed
    output reg right_click        // High when right button is pressed
);



    reg [5:0] Mouse_bits; // count number of bits receiving from the PS2 mouse 

   
    always @(posedge Mouse_Clk or posedge RESET)
    begin
        if(RESET==1)
            Mouse_bits <= 0;
        else if(Mouse_bits <=31) 
            Mouse_bits <= Mouse_bits + 1;
        else 
             Mouse_bits <= 0;
    end


    

endmodule